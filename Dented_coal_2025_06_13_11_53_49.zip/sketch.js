function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}// --- Variáveis Globais ---
let faseAtual = "fazenda"; // "fazenda" ou "cidade"

// Variáveis do Caminhão
let caminhaoX, caminhaoY;
const caminhaoVelocidade = 3;
const caminhaoLargura = 40;
const caminhaoAltura = 20;

// Variáveis do Fazendeiro
let fazendeiroX, fazendeiroY;
const fazendeiroVelocidade = 2;
const fazendeiroLargura = 20;
const fazendeiroAltura = 30;

// Variáveis dos Alimentos na Fazenda
let alimentosFazenda = [];
const tamanhoAlimento = 15;
let alimentosColetadosCount = 0; // Contador de alimentos coletados

// Variáveis dos Destinos na Cidade
let destinosCidade = [];
let entregasRealizadasCount = 0; // Contador de entregas feitas

// Inventário do Jogador (o que o caminhão/fazendeiro está carregando)
let inventario = [];

let mensagem = ""; // Para exibir mensagens no jogo

// --- Função setup() - Configurações Iniciais ---
function setup() {
  createCanvas(800, 600);
  iniciarFaseFazenda(); // Inicia a primeira fase
}

// --- Função draw() - Loop Principal do Jogo ---
function draw() {
  if (faseAtual === "fazenda") {
    desenharFaseFazenda();
    moverCaminhao();
    verificarColetaAlimentos();
  } else if (faseAtual === "cidade") {
    desenharFaseCidade();
    moverFazendeiro();
    verificarEntregaAlimentos();
  }

  // Desenha a mensagem
  fill(0);
  textSize(18);
  text(mensagem, 10, height - 20); // Posição da mensagem
}

// --- Funções de Inicialização das Fases ---

function iniciarFaseFazenda() {
  faseAtual = "fazenda";
  caminhaoX = 50;
  caminhaoY = height / 2;
  alimentosColetadosCount = 0;
  inventario = []; // Limpa o inventário

  // Posições dos alimentos na fazenda (você pode adicionar mais!)
  alimentosFazenda = [
    { x: 150, y: 100, tipo: "milho", coletado: false },
    { x: 250, y: 200, tipo: "tomate", coletado: false },
    { x: 100, y: 350, tipo: "cenoura", coletado: false },
    { x: 300, y: 450, tipo: "batata", coletado: false },
    { x: 400, y: 150, tipo: "ovo", coletado: false },
  ];
  mensagem = "Fase 1: Colete todos os alimentos com o caminhão!";
}

function iniciarFaseCidade() {
  faseAtual = "cidade";
  fazendeiroX = width / 2;
  fazendeiroY = height - 50;
  entregasRealizadasCount = 0;

  // Destinos na cidade (você pode adicionar mais!)
  destinosCidade = [
    { x: 100, y: 100, tipo: "mercado", precisa: ["milho", "tomate"], entregue: false },
    { x: 300, y: 200, tipo: "padaria", precisa: ["ovo"], entregue: false },
    { x: 500, y: 150, tipo: "restaurante", precisa: ["cenoura", "batata"], entregue: false },
  ];
  mensagem = "Fase 2: Entregue os alimentos nos mercados com o fazendeiro!";
}

// --- Funções da Fase da Fazenda ---

function desenharFaseFazenda() {
  background(100, 200, 100); // Fundo verde da fazenda (mais vibrante)

  // Desenhar áreas da fazenda (ex: plantações)
  fill(80, 160, 80); // Verde mais escuro
  rect(80, 80, 100, 120); // Plantação 1
  rect(200, 180, 150, 80); // Plantação 2
  rect(50, 320, 120, 100); // Plantação 3
  rect(350, 400, 100, 100); // Galinheiro/Curral

  desenharCaminhao();
  desenharAlimentosFazenda();

  // Exibir contagem de alimentos coletados
  fill(0);
  textSize(16);
  text("Alimentos Coletados: " + alimentosColetadosCount + "/" + alimentosFazenda.length, 10, 20);
  text("Inventário: " + inventario.join(", "), 10, 40);
}

function desenharCaminhao() {
  fill(255, 100, 0); // Caminhão laranja
  rect(caminhaoX, caminhaoY, caminhaoLargura, caminhaoAltura);
  fill(50); // Rodas
  ellipse(caminhaoX + 5, caminhaoY + caminhaoAltura, 10);
  ellipse(caminhaoX + caminhaoLargura - 5, caminhaoY + caminhaoAltura, 10);
}

function moverCaminhao() {
  if (keyIsDown(LEFT_ARROW)) {
    caminhaoX -= caminhaoVelocidade;
  }
  if (keyIsDown(RIGHT_ARROW)) {
    caminhaoX += caminhaoVelocidade;
  }
  if (keyIsDown(UP_ARROW)) {
    caminhaoY -= caminhaoVelocidade;
  }
  if (keyIsDown(DOWN_ARROW)) {
    caminhaoY += caminhaoVelocidade;
  }

  // Limitar o caminhão aos limites da tela
  caminhaoX = constrain(caminhaoX, 0, width - caminhaoLargura);
  caminhaoY = constrain(caminhaoY, 0, height - caminhaoAltura);
}

function desenharAlimentosFazenda() {
  for (let alimento of alimentosFazenda) {
    if (!alimento.coletado) {
      if (alimento.tipo === "milho") {
        fill(255, 255, 0); // Amarelo
        rect(alimento.x, alimento.y, tamanhoAlimento, tamanhoAlimento * 2); // Espiga de milho
      } else if (alimento.tipo === "tomate") {
        fill(255, 0, 0); // Vermelho
        ellipse(alimento.x, alimento.y, tamanhoAlimento);
      } else if (alimento.tipo === "cenoura") {
        fill(255, 165, 0); // Laranja
        triangle(alimento.x - tamanhoAlimento / 2, alimento.y + tamanhoAlimento / 2,
                 alimento.x + tamanhoAlimento / 2, alimento.y + tamanhoAlimento / 2,
                 alimento.x, alimento.y - tamanhoAlimento / 2);
      } else if (alimento.tipo === "batata") {
        fill(150, 75, 0); // Marrom
        ellipse(alimento.x, alimento.y, tamanhoAlimento * 1.2, tamanhoAlimento * 0.8);
      } else if (alimento.tipo === "ovo") {
        fill(255); // Branco
        ellipse(alimento.x, alimento.y, tamanhoAlimento, tamanhoAlimento * 0.8);
      }
    }
  }
}

function verificarColetaAlimentos() {
  for (let alimento of alimentosFazenda) {
    if (!alimento.coletado) {
      let d = dist(caminhaoX + caminhaoLargura / 2, caminhaoY + caminhaoAltura / 2, alimento.x, alimento.y);
      if (d < (caminhaoLargura / 2 + tamanhoAlimento / 2)) { // Colisão simples
        alimento.coletado = true;
        alimentosColetadosCount++;
        inventario.push(alimento.tipo); // Adiciona ao inventário
        mensagem = "Você coletou " + alimento.tipo + "!";

        if (alimentosColetadosCount === alimentosFazenda.length) {
          mensagem = "Todos os alimentos coletados! Indo para a cidade...";
          setTimeout(iniciarFaseCidade, 2000); // Espera 2 segundos e vai para a cidade
        }
      }
    }
  }
}

// --- Funções da Fase da Cidade ---

function desenharFaseCidade() {
  background(150, 200, 255); // Fundo azul claro da cidade (céu)

  // Desenhar ruas (cinza escuro)
  fill(80);
  rect(0, height * 0.7, width, 100); // Rua horizontal principal
  rect(width * 0.3, 0, 80, height); // Rua vertical

  // Desenhar edifícios (retângulos com cores variadas)
  fill(200); rect(50, 50, 80, 150); // Edifício 1
  fill(180); rect(250, 30, 100, 120); // Edifício 2
  fill(220); rect(width - 120, 80, 90, 100); // Edifício 3
  fill(190); rect(50, height - 150, 120, 100); // Edifício 4

  desenharDestinosCidade();
  desenharFazendeiro();

  // Exibir contagem de entregas
  fill(0);
  textSize(16);
  text("Entregas Realizadas: " + entregasRealizadasCount + "/" + destinosCidade.length, 10, 20);
  text("Inventário: " + inventario.join(", "), 10, 40);
}

function desenharFazendeiro() {
  fill(0, 150, 0); // Camisa verde
  rect(fazendeiroX, fazendeiroY, fazendeiroLargura, fazendeiroAltura);
  fill(139, 69, 19); // Chapéu marrom
  rect(fazendeiroX - 5, fazendeiroY - 10, fazendeiroLargura + 10, 10);
  fill(255, 200, 150); // Cor da pele
  ellipse(fazendeiroX + fazendeiroLargura / 2, fazendeiroY + 5, 15); // Cabeça
}

function moverFazendeiro() {
  if (keyIsDown(LEFT_ARROW)) {
    fazendeiroX -= fazendeiroVelocidade;
  }
  if (keyIsDown(RIGHT_ARROW)) {
    fazendeiroX += fazendeiroVelocidade;
  }
  if (keyIsDown(UP_ARROW)) {
    fazendeiroY -= fazendeiroVelocidade;
  }
  if (keyIsDown(DOWN_ARROW)) {
    fazendeiroY += fazendeiroVelocidade;
  }

  // Limitar o fazendeiro aos limites da tela
  fazendeiroX = constrain(fazendeiroX, 0, width - fazendeiroLargura);
  fazendeiroY = constrain(fazendeiroY, 0, height - fazendeiroAltura);
}

function desenharDestinosCidade() {
  for (let destino of destinosCidade) {
    if (!destino.entregue) {
      fill(50, 50, 200, 150); // Azul semi-transparente para o destino
      rect(destino.x, destino.y, 70, 70); // Área do mercado/destino

      // Desenhar o ícone do que o destino precisa
      fill(255); textSize(10);
      text("Precisa:", destino.x + 5, destino.y + 15);
      let yOffset = 30;
      for (let itemNecessario of destino.precisa) {
        text("- " + itemNecessario, destino.x + 5, destino.y + yOffset);
        yOffset += 12;
      }
    }
  }
}

function verificarEntregaAlimentos() {
  for (let destino of destinosCidade) {
    if (!destino.entregue) {
      let d = dist(fazendeiroX + fazendeiroLargura / 2, fazendeiroY + fazendeiroAltura / 2,
                   destino.x + 35, destino.y + 35); // Centro do destino
      if (d < (fazendeiroLargura / 2 + 35)) { // Colisão com o destino
        // Verifica se o jogador tem *todos* os itens que o destino precisa
        let podeEntregar = true;
        let itensEntreguesNesteDestino = [];

        for (let itemNecessario of destino.precisa) {
          let indiceNoInventario = inventario.indexOf(itemNecessario);
          if (indiceNoInventario !== -1) {
            itensEntreguesNesteDestino.push(itemNecessario);
          } else {
            podeEntregar = false; // Não tem um item necessário
            break;
          }
        }

        if (podeEntregar) {
          // Remove os itens do inventário
          for (let itemEntregue of itensEntreguesNesteDestino) {
            let idx = inventario.indexOf(itemEntregue);
            if (idx !== -1) {
              inventario.splice(idx, 1);
            }
          }
          destino.entregue = true;
          entregasRealizadasCount++;
          mensagem = "Entrega no " + destino.tipo + " realizada!";

          if (entregasRealizadasCount === destinosCidade.length) {
            mensagem = "Parabéns! Todas as entregas realizadas. Fim do Jogo!";
            // Você pode adicionar uma tela de vitória aqui
          }
        } else {
          mensagem = "Este mercado precisa de: " + destino.precisa.join(", ") + "!";
        }
      }
    }
  }
}

